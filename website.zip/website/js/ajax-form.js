$('document').ready(function() {

//=======PopUp Form ==========
$('#btn-pop').attr('disabled', true);
$('#btn-pop').css('cursor', 'not-allowed');

$('#name' && '#email' && '#mobile').keyup(function() {
    if ($(this).val().length !== 0) {
        $('#btn-pop').attr('disabled', false);
        $('#btn-pop').css('cursor', 'pointer');

    } else {
        $('#btn-pop').attr('disabled', true);
        $('#btn-pop').css('cursor', 'not-allowed');
    }
});
/* handle form validation */
$("#popupEnq").validate({
    ignore: ".ignore",
    rules: {
        name: {
            required: true,
            minlength: 4
        },
        email: {
            required: true,
            email: true
        },
        mobile:{
            required:true,
            minlength:10,
            maxlength:10
        },
        hiddenRecaptcha: {
            required: function () {
                if (grecaptcha.getResponse() == '') {
                    return true;
                } else {
                    return false;
                }
            }
        },
    },
    errorElement: "span",
    errorClass: "text-danger",
    messages: {

        name: { minlength: "Name at least 4 characters" },
        lname: { minlength: "Name at least 2 characters" },
        email: { email: "please enter a valid email address" },
        mobile: { minlength: "please enter a valid phone number" },
        mobile: { maxlength: "please enter a valid phone number less than 10 digits" },

    },
    submitHandler: submitForm
});
/* handle form submit */
function submitForm() {
    var data = $("#popupEnq").serialize();

    $.ajax({
        type: 'POST',
        url: 'ajax/popup-submit.php',
        data: data,
        beforeSend: function() {
            $("#btn-pop").css('cursor', 'progress');
            $("#btn-pop").attr('disabled','true');
            $("#btn-pop").html('<span class="spinner-grow spinner-grow-sm"></span>Loading..');
        },
        success: function(data) {
            if (data.status === 'error') {
                $("#btn-pop").html('Submit');
                $("#btn-pop").css('cursor', 'pointer');
                $("#btn-pop").removeAttr('disabled');

                Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: data.message,
                }).then(okay => {
                    if (okay) {
                    }
                });

            } else if (data.status === 'success') {
                    $("#btn-pop").html('Submit Successfully');
                    $("#btn-pop").css('cursor', 'pointer');
                    $("#btn-pop").removeAttr('disabled');
                    document.getElementById("popupEnq").reset();
                    localStorage.setItem('currentURL', data.redirecturl );
                    Swal.fire({
                        icon: 'success',
                        title: "Success",
                        html: ""+data.message+"",
                        showConfirmButton: false,
                        timer: 2500
                      });
                    setTimeout(thankYou,2500);
            } else {
               		$("#btn-pop").html('Submit');
                    $("#btn-pop").css('cursor', 'pointer');
                    $("#btn-pop").removeAttr('disabled');
                    Swal.fire({
                        icon: 'error',
                        title: "Error",
                        html: +data.message,
                        timer: 2000
                    }).then(okay => {
                        if (okay) {
                        }
                    });

            }
            function thankYou() {
                window.location.replace("thank-you.html"); // Removing it as with next form submit you will be adding the div again in your code.
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            $("#btn-pop").html('SEND');
            $("#btn-pop").css('cursor', 'pointer');
            $("#btn-pop").removeAttr('disabled');
            Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: textStatus + ' ' + errorThrown,
                    showConfirmButton: false,
                    timerProgressBar: true,
                    timer: 2000
                });
                    // alert("Status: " + textStatus); 
                    // alert("Error: " + errorThrown); 
        } 
    });
    return false;
}

//=======PopUp Form ==========
$('#btn-pop-onload').attr('disabled', true);
$('#btn-pop-onload').css('cursor', 'not-allowed');

$('#pname' && '#pemail' && '#pmobile').keyup(function() {
    if ($(this).val().length !== 0) {
        $('#btn-pop-onload').attr('disabled', false);
        $('#btn-pop-onload').css('cursor', 'pointer');

    } else {
        $('#btn-pop-onload').attr('disabled', true);
        $('#btn-pop-onload').css('cursor', 'not-allowed');
    }
});
/* handle form validation */
$("#popupOnload").validate({
    ignore: ".ignore",
    rules: {
        name: {
            required: true,
            minlength: 4
        },
        email: {
            required: true,
            email: true
        },
        mobile:{
            required:true,
            minlength:10,
            maxlength:10
        },
        hiddenRecaptcha: {
            required: function () {
                if (grecaptcha.getResponse() == '') {
                    return true;
                } else {
                    return false;
                }
            }
        },
        // hiddenRecaptcha: {
        //     // required: true
        // },
    },
    errorElement: "span",
    errorClass: "text-danger",
    messages: {

        name: { minlength: "Name at least 4 characters" },
        lname: { minlength: "Name at least 2 characters" },
        email: { email: "please enter a valid email address" },
        mobile: { minlength: "please enter a valid phone number" },
        mobile: { maxlength: "please enter a valid phone number less than 10 digits" },

    },
    submitHandler: submitFormonload
});
/* handle form submit */
function submitFormonload() {
    var data = $("#popupOnload").serialize();

    $.ajax({
        type: 'POST',
        url: 'ajax/popup-onload-submit.php',
        data: data,
        beforeSend: function() {
            $("#btn-pop-onload").css('cursor', 'progress');
            $("#btn-pop-onload").attr('disabled','true');
            $("#btn-pop-onload").html('<span class="spinner-grow spinner-grow-sm"></span>Loading..');
        },
        success: function(data) {
            if (data.status === 'error') {
                $("#btn-pop-onload").html('Submit');
                $("#btn-pop-onload").css('cursor', 'pointer');
                $("#btn-pop-onload").removeAttr('disabled');

                Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: data.message,
                }).then(okay => {
                    if (okay) {
                    }
                });

            } else if (data.status === 'success') {
                    $("#btn-pop-onload").html('Submit Successfully');
                    $("#btn-pop-onload").css('cursor', 'pointer');
                    $("#btn-pop-onload").removeAttr('disabled');
                    document.getElementById("popupOnload").reset();
                    localStorage.setItem('currentURL', data.redirecturl );
                    localStorage.setItem('pageload', "yes" );
                    Swal.fire({
                        icon: 'success',
                        title: "Success",
                        html: ""+data.message+"",
                        showConfirmButton: false,
                        timer: 2500
                      });
                    setTimeout(thankYou,2500);
            } else {
               		$("#btn-pop-onload").html('Submit');
                    $("#btn-pop-onload").css('cursor', 'pointer');
                    $("#btn-pop-onload").removeAttr('disabled');
                    Swal.fire({
                        icon: 'error',
                        title: "Error",
                        html: +data.message,
                        timer: 2000
                    }).then(okay => {
                        if (okay) {
                        }
                    });

            }
            function thankYou() {
                window.location.replace("thank-you.html"); // Removing it as with next form submit you will be adding the div again in your code.
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            $("#btn-pop-onload").html('SEND');
            $("#btn-pop-onload").css('cursor', 'pointer');
            $("#btn-pop-onload").removeAttr('disabled');
            Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: textStatus + ' ' + errorThrown,
                    showConfirmButton: false,
                    timerProgressBar: true,
                    timer: 2000
                });
                    // alert("Status: " + textStatus); 
                    // alert("Error: " + errorThrown); 
        } 
    });
    return false;
}

//=======Site Visit PopUp Form ==========
$('#btn-pop-site').attr('disabled', true);
$('#btn-pop-site').css('cursor', 'not-allowed');

$('#psname' && '#psemail' && '#psmobile').keyup(function() {
    if ($(this).val().length !== 0) {
        $('#btn-pop-site').attr('disabled', false);
        $('#btn-pop-site').css('cursor', 'pointer');

    } else {
        $('#btn-pop-site').attr('disabled', true);
        $('#btn-pop-site').css('cursor', 'not-allowed');
    }
});
/* handle form validation */
$("#popupSitevisit").validate({
    ignore: ".ignore",
    rules: {
        name: {
            required: true,
            minlength: 4
        },
        email: {
            required: true,
            email: true
        },
        mobile:{
            required:true,
            minlength:10,
            maxlength:10
        },
        time:{
            required:true,
            
        },
        datedata:{
            required:true,
            date:true,
        },
        hiddenRecaptcha: {
            required: function () {
                if (grecaptcha.getResponse() == '') {
                    return true;
                } else {
                    return false;
                }
            }
        },
    },
    errorElement: "span",
    errorClass: "text-danger",
    messages: {

        name: { minlength: "Name at least 4 characters" },
        lname: { minlength: "Name at least 2 characters" },
        email: { email: "please enter a valid email address" },
        mobile: { minlength: "please enter a valid phone number" },
        mobile: { maxlength: "please enter a valid phone number less than 10 digits" },

    },
    submitHandler: submitFormsite
});
/* handle form submit */
function submitFormsite() {
    var data = $("#popupSitevisit").serialize();

    $.ajax({
        type: 'POST',
        url: 'ajax/sitevisit-submit.php',
        data: data,
        beforeSend: function() {
            $("#btn-pop-site").css('cursor', 'progress');
            $("#btn-pop-site").attr('disabled','true');
            $("#btn-pop-site").html('<span class="spinner-grow spinner-grow-sm"></span>Loading..');
        },
        success: function(data) {
            if (data.status === 'error') {
                $("#btn-pop-site").html('Submit');
                $("#btn-pop-site").css('cursor', 'pointer');
                $("#btn-pop-site").removeAttr('disabled');

                Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: data.message,
                }).then(okay => {
                    if (okay) {
                    }
                });

            } else if (data.status === 'success') {
                    $("#btn-pop-site").html('Submit Successfully');
                    $("#btn-pop-site").css('cursor', 'pointer');
                    $("#btn-pop-site").removeAttr('disabled');
                    document.getElementById("popupSitevisit").reset();
                    localStorage.setItem('currentURL', data.redirecturl );
                    Swal.fire({
                        icon: 'success',
                        title: "Success",
                        //html: ""+data.message+"",
                        showConfirmButton: false,
                        timer: 2500
                      });
                    setTimeout(thankYou,2500);
            } else {
               		$("#btn-pop-site").html('Submit');
                    $("#btn-pop-site").css('cursor', 'pointer');
                    $("#btn-pop-site").removeAttr('disabled');
                    Swal.fire({
                        icon: 'error',
                        title: "Error",
                        html: +data.message,
                        timer: 2000
                    }).then(okay => {
                        if (okay) {
                        }
                    });

            }
            function thankYou() {
                window.location.replace("thank-you.html"); // Removing it as with next form submit you will be adding the div again in your code.
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            $("#btn-pop-site").html('SEND');
            $("#btn-pop-site").css('cursor', 'pointer');
            $("#btn-pop-site").removeAttr('disabled');
            Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: textStatus + ' ' + errorThrown,
                    showConfirmButton: false,
                    timerProgressBar: true,
                    timer: 2000
                });
                    // alert("Status: " + textStatus); 
                    // alert("Error: " + errorThrown); 
        } 
    });
    return false;
}

//=======staticEnq Form ==========
$('#btn-static').attr('disabled', true);
$('#btn-static').css('cursor', 'not-allowed');

$('#stname' && '#stemail' && '#stmobile').keyup(function() {
    if ($(this).val().length !== 0) {
        $('#btn-static').attr('disabled', false);
        $('#btn-static').css('cursor', 'pointer');

    } else {
        $('#btn-static').attr('disabled', true);
        $('#btn-static').css('cursor', 'not-allowed');
    }
});
/* handle form validation */
$("#staticEnq").validate({
    ignore: ".ignore",
    rules: {
        name: {
            required: true,
            minlength: 4
        },
        email: {
            required: true,
            email: true
        },
        mobile:{
            required:true,
            minlength:10,
            maxlength:10
        },
        hiddenRecaptcha: {
            required: function () {
                if (grecaptcha.getResponse() == '') {
                    return true;
                } else {
                    return false;
                }
            }
        },
        // updates:{required: true,},
    },
    errorElement: "span",
    errorClass: "text-danger",
    messages: {

        name: { minlength: "Name at least 4 characters" },
        lname: { minlength: "Name at least 2 characters" },
        email: { email: "please enter a valid email address" },
        mobile: { minlength: "please enter a valid phone number" },
        mobile: { maxlength: "please enter a valid phone number less than 10 digits" },

    },
    submitHandler: submitFormstaticEnq
});
/* handle form submit */
function submitFormstaticEnq() {
    var data = $("#staticEnq").serialize();

    $.ajax({
        type: 'POST',
        url: 'ajax/static-submit.php',
        data: data,
        beforeSend: function() {
            $("#btn-static").css('cursor', 'progress');
            $("#btn-static").attr('disabled','true');
            $("#btn-static").html('<span class="spinner-grow spinner-grow-sm"></span>Loading..');
        },
        success: function(data) {
            if (data.status === 'error') {
                $("#btn-static").html('Submit');
                $("#btn-static").css('cursor', 'pointer');
                $("#btn-static").removeAttr('disabled');

                Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: data.message,
                }).then(okay => {
                    if (okay) {
                    }
                });

            } else if (data.status === 'success') {
                    $("#btn-static").html('Submit Successfully');
                    $("#btn-static").css('cursor', 'pointer');
                    $("#btn-static").removeAttr('disabled');
                    document.getElementById("staticEnq").reset();
                    localStorage.setItem('currentURL', data.redirecturl );
                    Swal.fire({
                        icon: 'success',
                        title: "Success",
                        //html: ""+data.message+"",
                        showConfirmButton: false,
                        timer: 2500
                      });
                    setTimeout(thankYou,2500);
            } else {
               		$("#btn-static").html('Submit');
                    $("#btn-static").css('cursor', 'pointer');
                    $("#btn-static").removeAttr('disabled');
                    Swal.fire({
                        icon: 'error',
                        title: "Error",
                        html: +data.message,
                        timer: 2000
                    }).then(okay => {
                        if (okay) {
                        }
                    });

            }
            function thankYou() {
                window.location.replace("thank-you.html"); // Removing it as with next form submit you will be adding the div again in your code.
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            $("#btn-static").html('SEND');
            $("#btn-static").css('cursor', 'pointer');
            $("#btn-static").removeAttr('disabled');
            Swal.fire({
                    icon: 'error',
                    title: "Error",
                    html: textStatus + ' ' + errorThrown,
                    showConfirmButton: false,
                    timerProgressBar: true,
                    timer: 2000
                });
                    // alert("Status: " + textStatus); 
                    // alert("Error: " + errorThrown); 
        } 
    });
    return false;
}
});