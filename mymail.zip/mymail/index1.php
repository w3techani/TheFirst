<?php 
include "config.php";

// Insert record
if(isset($_POST['submit'])){

 echo  $title = $_POST['title'];
 echo  $short_desc = $_POST['short_desc'];
 echo $long_desc = $_POST['long_desc'];

 // if($title != ''){
echo "INSERT INTO contents(title,short_desc,long_desc) VALUES('".$title."','".$long_desc."','".$long_desc."') ";
    mysqli_query($con, "INSERT INTO contents(title,short_desc,long_desc) VALUES('".$title."','".$long_desc."','".$long_desc."') ");
   //3 header('location: index.php');
//  }
}

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Send NewsLetter</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
 <style type="text/css">
    .cke_textarea_inline{
       border: 1px solid black;
    }
    </style>

    <!-- CKEditor --> 
   <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
</head>
<body>
<!-- partial:index.partial.html -->
<!-- <!-- Appears on Tiny Blueprint (https://www.tiny.cloud/blog/) in articles:
 - Enhance Bootstrap forms with WYSIWYG editing-->
 <center>  <h1 class="h2 mb-4">Send NewsLetter</h1> </center>
<div class="container-fluid">
    <div class="row justify-content-md-center">
	 
	  <div class="col-md-6 col-lg-6">
	  <div style="margin-top:2%; height:95%; overflow:scroll;">
<table width="100%" class="table">
<tr>
<td width="5%">Sr No</td>
<td width="10%"> <input type="checkbox"  onClick="selectAcll(this)"  class="chk_boxes" label="check all"  />check all</td>
<td width="15%">Name</td>
<td width="10%">Email</td>

</tr>
<?php 
 $href=$_SERVER['REQUEST_URI'];
$i=1;
$sql = "select D,ClientName,email from w3_clients";
$data = mysqli_query($con,$sql);
while($arr= mysqli_fetch_array($data)){
	
	echo '<tr>
	
	
		<td>'.$i.'</td>
		<td> <input type="checkbox" name="module[]"  value="'.$arr['D'].'" > </td>
		<td>'.$arr['ClientName'].' </td>
		<td>'.$arr['email'].' </td>
	
	
		</tr>';
		$i++;
}
?>



</table>
</div>
	  
	</div>
	
        <div class="col-md-6 col-lg-6">
         
			
            <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" id="sub_name" placeholder="Your name">
            </div>

            <div class="form-group hidden"hidden>
              <label for="email">Email address</label>
              <input type="email" class="form-control" id="email" placeholder="Enter email">
              <small class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>

            <div class="form-group">
              <label>Description in detail</label>
			
              <textarea id='long_desc' name='long_desc' ></textarea>
            </div>

            <div class="form-group hidden"hidden>
                <label for="phone">Primary phone number</label>
                <input type="text" class="form-control" id="phone" placeholder="">
            </div>

            <hr>

            <div class="form-group form-check hidden"hidden>
                <input type="checkbox" class="form-check-input" id="terms">
                <label class="form-check-label" for="terms">I agree to the <a href="#">terms and conditions</a></label>
            </div>

            <button  name="submit" class="btn btn-primary" onClick="grant_perm()">Submit</button>
			 
			
			  
        </div>
		
		
		
		
		
		
		
		
		
    </div>
</div>
<!-- partial -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script type="text/javascript">

// Initialize CKEditor
//CKEDITOR.inline( 'short_desc' );

CKEDITOR.replace('long_desc',{

  width: "600px",
  height: "200px"

}); 


function selectAcll(source) {
		//alert('hello');
		checkboxes = document.getElementsByName('module[]');
		//alert(checkboxes);
		for(var i in checkboxes)
			
			checkboxes[i].checked = source.checked;
			
	}
	
	
	
	
	
	
	
	
	
	
function grant_perm(){
	//alert('hello');
	//var ereqid = $('#ereqid').val();
	var ereqid = 1;
	var sub_name = $('#sub_name').val();
	//	alert(sub_name);
	//var long_desc = $('#long_desc').text();
//	var message = $('textarea#long_desc').val();
	var message = CKEDITOR.instances['long_desc'].getData();
	alert(message);
	var modules = []
	$("input[name='module[]']:checked").each(function (){
		modules.push($(this).val());
	});
	//alert(modules);
	//alert(ereqid);
	$.post('send_newsletter.php', {sub_name:sub_name,long_desc:message,ereqid:ereqid,modules:modules,action:'grant_perm'}, function(response) {
		//exit();
		//window.location.reload();
	//	location.reload();
		
		
	});
}
	
	
	
</script>
</body>
</html>
