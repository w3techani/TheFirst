<?php
session_start();

include_once("config.php");
//use Dompdf\Dompdf;
include("class.phpmailer.php");
$action = $_POST['action'];



if($action == 'grant_perm'){
	
	$date12 = date('Y-m-d');
	$msg = $_POST['long_desc'];
	$subject = $_POST['sub_name'];
	
		
	foreach($_POST['modules'] as $module){
	

		 $str112 = "select D,ClientName,email from mail_client where D=".$module." ";
					$query112 = mysqli_query($con,$str112);
					$checkprod112 = mysqli_fetch_array($query112);
					$D = $checkprod112['D'];
					$ClientName = $checkprod112['ClientName'];
					$toid = $checkprod112['email'];

	
$mail             = new PHPMailer();

$body             = "<h1>Test mail</h1>";


$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "mail.w3techsolution.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
#$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "mail.w3techsolution.com";      // sets  as the SMTP server
$mail->Port       = 587;                   // set the SMTP port for the server
$mail->Username   = "ani@w3techsolution.com";  // username
$mail->Password   = "Prakash@121";            // password

$mail->SetFrom('ani@w3techsolution.com', 'No Reply to');

$mail->Subject    = $subject;



$mail->MsgHTML($msg);
//$mail->AddAttachment($loc);
$address = $toid;
$mail->AddAddress($address, $ClientName);

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
	
	
	
}

	}








if($action == 'grant_perm1'){
	
	foreach($_POST['modules'] as $module){
		
		echo $chk = "update product set status='N' where  id='".$module."'";
		exit;
		$rs = mysql_query($chk);
		$num = mysql_num_rows($rs);
		
	}
	if($num){
		echo 'Y';
	}else{
		echo 'N';
	}
}







$action = $_POST['action'];
if($action == 'userdetail'){
   	 $str = "select * from user_role,users where user_role.id='".$_POST['id']."' && users.id='".$_POST['id']."'";
	$rs = mysql_query($str);
	$arr = mysql_fetch_array($rs);
	echo json_encode($arr);
	exit; 
}







?>