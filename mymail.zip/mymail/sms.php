<?php

    $message = 'Dear Candidate,

Congratulations !

You are now registered with M Gheewala Global HR Consultants.

Username :
Password :

Completed profileshave a greater chance of getting you the best opportunities globally and have better chance for selection. 

Please login at jobs.mgheewala.com at the earliest to view the vacancies.

Web : www.mgheewala.com
Email : jobs@mgheewala.com
';
	$message = urlencode($message);
   // $user = '9730262314'; 
    $user = $mobile; 
   // $apikey = 'API_KEY_HERE';
    $baseurl = 'http://k3digitalmedia.co.in/websms/api/http/index.php?username=k3mghee&apikey=24D4A-01AAF&apirequest=Text&route=Transactional&sender=JOBSMG';
 
  echo  $url = $baseurl.'&mobile='.$user.'&message='.$message;    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_POST, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
  
    // Use file get contents when CURL is not installed on server.
    if(!$response){
        $response = file_get_contents($url);
    }
	





?>