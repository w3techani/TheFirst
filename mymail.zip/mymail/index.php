<?php 
include "config.php";
error_reporting(0);
// Insert record
if(isset($_POST['submit'])){

 echo  $title = $_POST['title'];
 echo  $short_desc = $_POST['short_desc'];
 echo $long_desc = $_POST['long_desc'];

 // if($title != ''){
echo "INSERT INTO contents(title,short_desc,long_desc) VALUES('".$title."','".$long_desc."','".$long_desc."') ";
    mysqli_query($con, "INSERT INTO contents(title,short_desc,long_desc) VALUES('".$title."','".$long_desc."','".$long_desc."') ");
   //3 header('location: index.php');
//  }
}

?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Send Mail</title>
 <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
 <style type="text/css">
    .cke_textarea_inline{
       border: 1px solid black;
    }
 </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
    <!-- CKEditor --> 
   <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
</head>
<body>
<!-- partial:index.partial.html -->
<!-- <!-- Appears on Tiny Blueprint (https://www.tiny.cloud/blog/) in articles:
 - Enhance Bootstrap forms with WYSIWYG editing-->
 <center>  <h1 class="h2 mb-4">Send €mail</h1> </center>
<div class="container-fluid">
    <div class="row justify-content-md-center">
	 
	  <div class="col-md-6 col-lg-6">
	  	  <form method="POST" action="">
	  <div class="row hidden" hidden>	
	  

	            <div class="col-sm-4">
				<div class="form-group">
				
				<select class="form-control selectpicker"   name="location"  id="pid11" data-show-subtext="true" data-live-search="true">
	<option value="">Location</option>
									
										<?php
			                                  $sup=mysqli_query($con,'select D,name from w3_state where status ="Y"');
			                                  while($suparr=mysqli_fetch_assoc($sup))
											  {
												   $er14 = ($suparr['D']== $Country) ? 'selected' : '';
				                                  echo '<option value="'.$suparr['D'].'" '.$er14.'>'.$suparr['name'].'</option>';
			                                  }
			                                ?>	
	</select>
				
				</div>
				</div>
				
	            <div class="col-sm-5">
				<div class="form-group">
			
			<select class="form-control selectpicker"  name="company"  id="pid11" data-show-subtext="true" data-live-search="true">
	<option></option>
	<?php
			$sup=mysqli_query($con,'select CompanyName,D from w3_company where status = "Y"');
			while($suparr=mysqli_fetch_assoc($sup)){
				echo '<option value="'.$suparr['D'].'" onchange="shopproduct('.$suparr['id'].');">'.$suparr['CompanyName'].'</option>';
			}
			?>
	</select>
				
				</div>
				</div>
				
     <div class="col-sm-2">
	
	<input for="3" accesskey="6"  name="3"  type="submit" name="ofgfdk" class="btn btn-default my-button" value="ok(ALT+6)">
	
	
	</div>	
			
</form>			
				
				</div>
	  
	  
	  
	  
	  <div style="margin-top:2%; height:800px; overflow:scroll;">
<table width="100%" class="table" id="mytableID">
<tr>
<td width="5%">Sr No</td>
<td width="10%"> <input type="checkbox"  onClick="selectAcll(this)"  class="chk_boxes" label="check all"  />check all</td>
<td width="15%">Name</td>

<td width="10%">Email</td>

</tr>
<?php 

//if(isset($_POST['company'])){
	
	$company = $_POST['company'];
	$location = $_POST['location'];

  $whereClauses = array(); 
						 
        if (! empty($company)) 
			$whereClauses[] ="CompanyId = '".mysql_real_escape_string($company)."'";

                if (! empty($location)) 
			$whereClauses[] ="LocationID = '".mysql_real_escape_string($location)."'"; 
		
			  $where = "where D != ''";
			if (count($whereClauses) > 0) 
            { 
                $where = ' '.$where.'  AND  '.implode(' AND ',$whereClauses); 
            } 

$i=1;
 $sql = "select D,ClientName,email from mail_client ".$where;
$data = mysqli_query($con,$sql);
while($arr= mysqli_fetch_array($data)){
	
	echo '<tr>
	
	
		<td>'.$i.'</td>
		<td> <input type="checkbox" name="module[]"  value="'.$arr['D'].'" > </td>
		<td>'.$arr['ClientName'].' </td>
	
		
		<td>'.$arr['email'].' </td>
	
		</tr>';
		$i++;
}


//}
?>



</table>
</div>
	  
	</div>
	
        <div class="col-md-6 col-lg-6">
         
			
            <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" id="sub_name" placeholder="Your name">
            </div>

            <div class="form-group hidden"hidden>
              <label for="email">Email address</label>
              <input type="email" class="form-control" id="email" placeholder="Enter email">
              <small class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>

            <div class="form-group">
              <label>Description in detail</label>
			
              <textarea id='long_desc' name='long_desc' ></textarea>
            </div>

            <div class="form-group "hidden>
                <label for="phone">Primary phone number</label>
                <input type="text" class="form-control" id="phone" placeholder="">
            </div>

            <hr>

            <div class="form-group form-check hidden"hidden>
                <input type="checkbox" class="form-check-input" id="terms">
                <label class="form-check-label" for="terms">I agree to the <a href="#">terms and conditions</a></label>
            </div>

            <button  name="submit" class="btn btn-primary" onClick="grant_perm()">Submit</button>
			 
			
			  
        </div>
		
		
		
		
		
		
		
		
		
    </div>
</div>
<!-- partial -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script type="text/javascript">

// Initialize CKEditor
//CKEDITOR.inline( 'short_desc' );

CKEDITOR.replace('long_desc',{

  width: "600px",
  height: "200px"

}); 


function selectAcll(source) {
		//alert('hello');
		checkboxes = document.getElementsByName('module[]');
		//alert(checkboxes);
		for(var i in checkboxes)
			
			checkboxes[i].checked = source.checked;
			
	}
	
	
	
	
	
	
	
	
	
	
function grant_perm(){
	//alert('hello');
	//var ereqid = $('#ereqid').val();
	var ereqid = 1;
	var sub_name = $('#sub_name').val();
	//	alert(sub_name);
	//var long_desc = $('#long_desc').text();
//	var message = $('textarea#long_desc').val();
	var message = CKEDITOR.instances['long_desc'].getData();
	//alert(message);
	var modules = []
	$("input[name='module[]']:checked").each(function (){
		modules.push($(this).val());
	});
	//alert(modules);
	//alert(ereqid);
	$.post('send_newsletter.php', {sub_name:sub_name,long_desc:message,ereqid:ereqid,modules:modules,action:'grant_perm'}, function(response) {
		//exit();
		window.location.reload();
		location.reload();
		
		
	});
}
	
	
	
</script>
<script type="text/javascript"> 
              
            $(document).ready(function() { 
        
                              
            }); 
        </script> 
</body>
</html>
