
<?php

function mailsent($toid,$loc,$msg, $subject)
{
include("class.phpmailer.php");

$mail             = new PHPMailer();

$body             = "<h1>Test mail</h1>";


$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "mail.mgheewala.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
#$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
$mail->Host       = "mail.mgheewala.com";      // sets  as the SMTP server
$mail->Port       = 2525;                   // set the SMTP port for the server
$mail->Username   = "jobs-mgheewala";  // username
$mail->Password   = "grf64shx82";            // password

$mail->SetFrom('jobs@mgheewala.com', 'MGheewala.com');

$mail->Subject    = $subject;



$mail->MsgHTML($msg);
$mail->AddAttachment($loc);
$address = $toid;
$mail->AddAddress($address, "user2");

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
}



?>
