<?php

//update_last_activity.php

include('config.php');
session_start();

$query = "
UPDATE login_details 
SET last_activity = now() 
WHERE login_details_id = '1'
";

$statement = $connect->prepare($query);

$statement->execute();

?>